Lors de la cr�ation du projet (avec IntelliJ IDEA), il faut s�lectionner le dossier "solution" en tant que Project Root.

Les Unit Tests requi�rent JUnit. Il faut �galement changement le chemin relatif vers le dossier des fichiers de test dans GestionnaireTest � la ligne 46.